#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<QDialog>
#include <QMainWindow>
#include<QLabel>
#include <QProgressBar>
#include <QSpinBox>
#include <QFontComboBox>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    QLabel *fLabCurFile;//状态栏里显示当前文件的Label
    QProgressBar *progressBar1;//状态栏上的进度条
    QSpinBox *spinFontSize;//字体大小spinBox
    QFontComboBox *comboFont;//字体名称comboBox
    void initUI();
public slots:
    void on_actFondBold_triggered(bool checked);
    void on_spinBoxFontSize_valueChanged(int aFontSize);
    void on_comboFont_currentIndexChanged(const QString &arg1);
public:
    void initSignalSlots();
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
